SET search_path = public, pg_catalog;

--
-- Drops the old views.
--
DROP VIEW analysis_group_listing;
DROP VIEW analysis_job_types;
DROP VIEW analysis_listing;
DROP VIEW deployed_component_listing;
DROP VIEW rating_listing;
DROP VIEW job_listings;

