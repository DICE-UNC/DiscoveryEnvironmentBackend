{:dependencies [[cheshire "5.0.2"]]}
