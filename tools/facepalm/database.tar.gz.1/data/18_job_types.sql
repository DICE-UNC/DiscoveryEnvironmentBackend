-- Populates the job_types table.

INSERT INTO job_types(id, name) VALUES
    ( 'AD069D9F-E38F-418C-84F6-21F620CADE77', 'DE' ),
    ( '61433582-A271-4154-B3C5-F4C1D91DB2A4', 'Agave' );
