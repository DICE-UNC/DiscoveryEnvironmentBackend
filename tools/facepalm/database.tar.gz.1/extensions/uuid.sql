SET search_path = public, pg_catalog;

--
-- Adds functions for generating UUIDs.
--
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
