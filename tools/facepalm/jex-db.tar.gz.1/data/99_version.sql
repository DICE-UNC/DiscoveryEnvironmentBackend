INSERT INTO version (version) VALUES ('1.9.3:20141114.01');
INSERT INTO version (version) VALUES ('2.1.0:20150903.01');
